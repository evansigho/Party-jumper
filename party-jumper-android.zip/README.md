# Party Jumper - Card games (Android)

Party game hub for Android: Party Jumper forehead charades plus Ludo, Crazy Eights, Imposter,
Most Likely To, Truth or Dare 18+, Never Have I Ever 18+, Connect Four, Tic-Tac-Toe, Sudoku,
Memory Match and Higher or Lower. Play on one phone, or link 2–15 phones on the same Wi-Fi.

---

## 1. Get the APK (free, no computer software needed)

The APK is built for you by GitHub in the cloud. Takes about 10 minutes the first time.

1. Make a free account at **github.com** and create a **New repository** (name it `party-jumper`,
   keep it Private if you like).
2. In the repo tap **Add file → Upload files** and upload **`party-jumper-android.zip`**
   (the whole zip, don't unpack it). Tap **Commit changes**.
3. Tap **Add file → Create new file**. For the file name type exactly:
   `.github/workflows/build-apk.yml`
   Paste in the contents of **`build-apk.yml`** and tap **Commit changes**.
4. Open the **Actions** tab. A build called "Build Party Jumper APK" starts by itself.
   When it shows a green tick, go to the repo's **Releases** (right side on desktop, or
   `github.com/YOUR-NAME/party-jumper/releases`) and download **`PartyJumper.apk`**.

To update the game later, upload a new zip (step 2) and a new build appears under Releases.
New builds install over the old one and keep everyone's saved progress.

## 2. Install on the phone (Tecno Pop or any Android 7+)

1. Open the downloaded `PartyJumper.apk`.
2. If Android asks, allow **Install unknown apps** for your browser or Files app, then go back.
3. Tap **Install**, then **Open**. If Play Protect warns about an unknown developer,
   tap **More details → Install anyway** (normal for apps outside the Play Store).

Send the same APK to your friends' phones (WhatsApp, Bluetooth, Xender) to play together.

## 3. Playing on many phones

**Everyone needs the app and the same Wi-Fi.** No router? The host turns on their phone's
**Hotspot** and everyone else connects to it. Games use the Wi-Fi only; no internet data is used.

**Host (the phone that starts the room)**
1. Open Party Jumper and tap **Host room** (or pick a game → **Many phones**).
2. A 6-character room code appears, like `A7K2Q9`. Say it out loud or show your screen.
3. As each friend asks to join, a pop-up drops down: **Accept**, **Waiting room** or **Reject**.
   - *Waiting room* keeps them connected but not in the game yet. Tap **Let in** any time.
   - Tap **✕** next to a player to remove them.
   - "Nearby on this Wi-Fi" shows phones that have opened Join but haven't entered the code yet.
4. Pick a game and tap **Start**. Up to 15 phones.

**Players**
1. Open Party Jumper and tap **Join room**.
2. The host's room appears under **Rooms on this Wi-Fi**. Tap it.
3. Type the 6-character code and tap **Ask to join**.
4. Wait for the host to accept. You'll hear a chime when you're in; the game opens on your phone
   when the host starts. Your cards, roles and votes stay on your own screen.

**If it doesn't connect**
- Check every phone is on the *same* Wi-Fi name (not one on mobile data).
- Room not listed? Just type the code; it still finds the host on most networks.
- Hotel, school and office Wi-Fi often blocks phones from seeing each other. Use the host's hotspot.
- Keep the app open on the host phone. If the host leaves, the room closes.
- If a player drops off mid-game, a CPU player takes their seat (Ludo, Crazy Eights,
  Connect Four, Tic-Tac-Toe) so the game can finish.

## 4. Sign-in

Anyone can play as a guest. Signing in (email in this build) saves scores, streaks and custom
decks on the phone. Google and Facebook sign-in need a Firebase project and a Facebook app ID;
they're the next step before a Play Store release.

## For developers

- Game code: `www/index.html` (single file). Wi-Fi rooms: `android/app/src/main/java/com/tafmedia/partyjumper/LanRoomPlugin.java`
  (TCP room server on port 47700, UDP room/player announcements on 47701).
- Local build: `npm install && npx cap sync android`, then open `android/` in Android Studio and press Run.
- Needs Node 22+, JDK 21. Capacitor 8.
- `partyjumper-debug.keystore` is a shared test key. Create your own private key before publishing on Google Play.
