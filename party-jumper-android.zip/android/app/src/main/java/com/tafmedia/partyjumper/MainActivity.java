package com.tafmedia.partyjumper;

import android.os.Bundle;
import android.view.WindowManager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(LanRoomPlugin.class);
        super.onCreate(savedInstanceState);
        // Keep the screen awake while the game is open (forehead rounds, turns, waiting rooms).
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
}
