package com.tafmedia.partyjumper;

import android.content.Context;
import android.net.wifi.WifiManager;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Same-Wi-Fi game rooms for Party Jumper.
 *  - Host phone: TCP room server (newline-delimited JSON) + UDP "room here" beacon.
 *  - Player phone: UDP discovery of nearby rooms/players + TCP connection to the host.
 * Works on a shared router or on the host's own mobile hotspot. No internet needed.
 */
@CapacitorPlugin(name = "LanRoom")
public class LanRoomPlugin extends Plugin {

    private final ExecutorService io = Executors.newCachedThreadPool();

    // host side
    private volatile ServerSocket server;
    private final Map<Integer, Conn> clients = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    // player side
    private volatile Conn host;

    // beacon + discovery
    private volatile String beaconText = null;
    private volatile int beaconPort = 47701;
    private ScheduledExecutorService beaconTimer;
    private DatagramSocket beaconSock;
    private volatile DatagramSocket discSock;
    private WifiManager.MulticastLock mlock;

    static final class Conn {
        final Socket s;
        final int id;
        final PrintWriter out;

        Conn(Socket s, int id) throws IOException {
            this.s = s;
            this.id = id;
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8)), false);
        }

        synchronized void send(String text) {
            out.write(text);
            out.write('\n');
            out.flush();
        }

        void close() {
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    /* ---------- network info ---------- */

    @PluginMethod
    public void getNetworkInfo(PluginCall call) {
        JSObject r = new JSObject();
        String ip = localIp();
        r.put("ip", ip);
        r.put("connected", ip != null);
        call.resolve(r);
    }

    /** Prefer the Wi-Fi or hotspot interface; never mobile data. */
    private static String localIp() {
        String fallback = null;
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String n = ni.getName();
                boolean mobile = n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("pdp") || n.startsWith("tun");
                if (mobile) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress()) continue;
                    String ip = a.getHostAddress();
                    if (n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap")) return ip;
                    if (fallback == null) fallback = ip;
                }
            }
        } catch (Exception ignored) { }
        return fallback;
    }

    private static List<InetAddress> broadcastAddrs() {
        List<InetAddress> list = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null && !list.contains(b)) list.add(b);
                }
            }
            InetAddress all = InetAddress.getByName("255.255.255.255");
            if (!list.contains(all)) list.add(all);
        } catch (Exception ignored) { }
        return list;
    }

    /* ---------- host: room server ---------- */

    @PluginMethod
    public void startServer(PluginCall call) {
        final int port = call.getInt("port", 47700);
        stopServerInternal();
        final AtomicBoolean answered = new AtomicBoolean(false);
        io.execute(() -> {
            try {
                ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(port));
                server = ss;
                answered.set(true);
                call.resolve();
                while (!ss.isClosed()) {
                    Socket s = ss.accept();
                    int id = nextId.getAndIncrement();
                    Conn c = new Conn(s, id);
                    clients.put(id, c);
                    JSObject e = new JSObject();
                    e.put("id", id);
                    e.put("ip", s.getInetAddress().getHostAddress());
                    notifyListeners("clientConnected", e);
                    io.execute(() -> readClient(c));
                }
            } catch (Exception ex) {
                if (!answered.getAndSet(true)) call.reject("Could not open the room on this network: " + ex.getMessage());
            }
        });
    }

    private void readClient(Conn c) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(c.s.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = in.readLine()) != null) {
                JSObject e = new JSObject();
                e.put("id", c.id);
                e.put("text", line);
                notifyListeners("clientMessage", e);
            }
        } catch (Exception ignored) {
        } finally {
            c.close();
            if (clients.remove(c.id) != null) {
                JSObject e = new JSObject();
                e.put("id", c.id);
                notifyListeners("clientClosed", e);
            }
        }
    }

    @PluginMethod
    public void send(PluginCall call) {
        Integer id = call.getInt("id");
        String text = call.getString("text", "");
        Conn c = id == null ? null : clients.get(id);
        if (c == null) { call.resolve(); return; }
        io.execute(() -> {
            try { c.send(text); } catch (Exception ignored) { }
            call.resolve();
        });
    }

    @PluginMethod
    public void closeClient(PluginCall call) {
        Integer id = call.getInt("id");
        Conn c = id == null ? null : clients.get(id);
        if (c != null) c.close();
        call.resolve();
    }

    @PluginMethod
    public void stopServer(PluginCall call) {
        stopServerInternal();
        call.resolve();
    }

    private void stopServerInternal() {
        ServerSocket ss = server;
        server = null;
        if (ss != null) try { ss.close(); } catch (Exception ignored) { }
        for (Conn c : clients.values()) c.close();
        clients.clear();
    }

    /* ---------- player: connect to host ---------- */

    @PluginMethod
    public void connect(PluginCall call) {
        final String h = call.getString("host");
        final int port = call.getInt("port", 47700);
        if (h == null) { call.reject("No host address"); return; }
        disconnectInternal();
        io.execute(() -> {
            Conn c;
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(h, port), 4000);
                c = new Conn(s, 0);
                host = c;
            } catch (Exception ex) {
                call.reject("Could not reach that room");
                return;
            }
            call.resolve();
            try (BufferedReader in = new BufferedReader(new InputStreamReader(c.s.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = in.readLine()) != null) {
                    JSObject e = new JSObject();
                    e.put("text", line);
                    notifyListeners("message", e);
                }
            } catch (Exception ignored) {
            } finally {
                c.close();
                if (host == c) {
                    host = null;
                    notifyListeners("closed", new JSObject());
                }
            }
        });
    }

    @PluginMethod
    public void sendToHost(PluginCall call) {
        String text = call.getString("text", "");
        Conn c = host;
        if (c == null) { call.resolve(); return; }
        io.execute(() -> {
            try { c.send(text); } catch (Exception ignored) { }
            call.resolve();
        });
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        disconnectInternal();
        call.resolve();
    }

    private void disconnectInternal() {
        Conn c = host;
        host = null;
        if (c != null) c.close();
    }

    /* ---------- beacon: "I'm here" every second ---------- */

    @PluginMethod
    public void startBeacon(PluginCall call) {
        beaconText = call.getString("text", "{}");
        beaconPort = call.getInt("port", 47701);
        synchronized (this) {
            if (beaconTimer == null) {
                beaconTimer = Executors.newSingleThreadScheduledExecutor();
                beaconTimer.scheduleAtFixedRate(this::sendBeacon, 0, 1000, TimeUnit.MILLISECONDS);
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void updateBeacon(PluginCall call) {
        beaconText = call.getString("text", beaconText);
        call.resolve();
    }

    private void sendBeacon() {
        String t = beaconText;
        if (t == null) return;
        try {
            if (beaconSock == null) {
                beaconSock = new DatagramSocket();
                beaconSock.setBroadcast(true);
            }
            byte[] b = t.getBytes(StandardCharsets.UTF_8);
            for (InetAddress addr : broadcastAddrs()) {
                try { beaconSock.send(new DatagramPacket(b, b.length, addr, beaconPort)); } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
    }

    @PluginMethod
    public void stopBeacon(PluginCall call) {
        stopBeaconInternal();
        call.resolve();
    }

    private synchronized void stopBeaconInternal() {
        beaconText = null;
        if (beaconTimer != null) { beaconTimer.shutdownNow(); beaconTimer = null; }
        if (beaconSock != null) { beaconSock.close(); beaconSock = null; }
    }

    /* ---------- discovery: hear nearby rooms and players ---------- */

    @PluginMethod
    public void startDiscovery(PluginCall call) {
        final int port = call.getInt("port", 47701);
        stopDiscoveryInternal();
        try {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                mlock = wm.createMulticastLock("partyjumper");
                mlock.setReferenceCounted(false);
                mlock.acquire();
            }
        } catch (Exception ignored) { }
        final AtomicBoolean answered = new AtomicBoolean(false);
        io.execute(() -> {
            try {
                DatagramSocket ds = new DatagramSocket(null);
                ds.setReuseAddress(true);
                ds.setBroadcast(true);
                ds.bind(new InetSocketAddress(port));
                discSock = ds;
                answered.set(true);
                call.resolve();
                byte[] buf = new byte[8192];
                while (!ds.isClosed()) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    ds.receive(p);
                    JSObject e = new JSObject();
                    e.put("ip", p.getAddress().getHostAddress());
                    e.put("text", new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8));
                    notifyListeners("beacon", e);
                }
            } catch (Exception ex) {
                if (!answered.getAndSet(true)) call.reject("Could not listen for nearby phones: " + ex.getMessage());
            }
        });
    }

    @PluginMethod
    public void stopDiscovery(PluginCall call) {
        stopDiscoveryInternal();
        call.resolve();
    }

    private void stopDiscoveryInternal() {
        DatagramSocket ds = discSock;
        discSock = null;
        if (ds != null) ds.close();
        if (mlock != null) {
            try { if (mlock.isHeld()) mlock.release(); } catch (Exception ignored) { }
            mlock = null;
        }
    }

    @Override
    protected void handleOnDestroy() {
        stopServerInternal();
        disconnectInternal();
        stopBeaconInternal();
        stopDiscoveryInternal();
        io.shutdownNow();
    }
}
